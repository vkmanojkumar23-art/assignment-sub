MYVERSE COLLEGE TASK TRACKER — PWA

Files:
- index.html: app
- manifest.webmanifest: installable app metadata
- sw.js: offline cache
- icon.svg: app icon

To publish with GitHub Pages:
1. Create a new public GitHub repository (for example: myverse-college-tracker).
2. Upload all four files from this folder to the repository root.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait for GitHub Pages to publish. Open the Pages URL in Chrome on Android.
7. Tap the app's Install app button, or Chrome ⋮ > Install app / Add to Home screen.

Tasks and completion status are saved in local storage on that device/browser. This version does not sync between devices.
